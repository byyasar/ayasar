// Copyright 2022 QMK
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#define CH_CFG_ST_TIMEDELTA 0

#include_next <chconf.h>
